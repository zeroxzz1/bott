import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "200"))

DEVS = list(map(int, os.getenv("DEVS", "5933844322").split()))

API_ID = int(os.getenv("API_ID", "20227346"))

API_HASH = os.getenv("API_HASH", "0600f98a6c4721aeed6677480298ad88")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8400988793:AAGB1WlDX84y1_8k8EjkDsStZ67xG5Jkeq0")

OWNER_ID = int(os.getenv("OWNER_ID", "5933844322"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002312835928").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://zero:zero@cluster0.rysxs6x.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1003282036854"))
